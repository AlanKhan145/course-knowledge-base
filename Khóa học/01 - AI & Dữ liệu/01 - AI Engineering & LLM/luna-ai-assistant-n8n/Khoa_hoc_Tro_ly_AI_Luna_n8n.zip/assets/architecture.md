# Sơ đồ kiến trúc AI Agent Luna

```mermaid
flowchart TB
  U[Người dùng] --> C[Chat Trigger]
  C --> A[AI Agent: Luna]
  M[Chat Model] -.-> A
  S[Simple Memory] -.-> A
  A --> G[Get Memories]
  A --> I[Insert Memory]
  A --> P[Update Memory]
  G --> D[(Memories Data Table)]
  I --> D
  P --> D
  A --> W[SerpApi / Wikipedia / Hacker News]
  A --> R[Phản hồi tới người dùng]
```
