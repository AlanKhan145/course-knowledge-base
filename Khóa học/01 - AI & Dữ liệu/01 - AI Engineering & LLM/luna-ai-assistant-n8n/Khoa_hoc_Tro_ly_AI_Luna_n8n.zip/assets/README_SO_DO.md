# Phụ lục — Sơ đồ kiến trúc và luồng ký ức của trợ lý Luna

Tài liệu này tập hợp hai sơ đồ Mermaid có thể đọc trực tiếp trong các ứng dụng Markdown hỗ trợ Mermaid. Bạn có thể thay đổi tên node cho khớp với workflow đang chạy trong n8n. Các sơ đồ mang tính logic, không phải file cấu hình JSON có thể import tự động vào n8n.

## 1. Kiến trúc tổng quan

```mermaid
flowchart TB
  U[Người dùng] --> C[Chat Trigger]
  C --> A[AI Agent: Luna]
  M[Chat Model qua OpenRouter] -.-> A
  S[Simple Memory] -.-> A
  A --> G[Get Memories]
  A --> I[Insert Memory]
  A --> P[Update Memory]
  G --> D[(Memories Data Table)]
  I --> D
  P --> D
  A --> W[SerpApi / Wikipedia / Hacker News]
  A --> R[Phản hồi tới người dùng]
```

**Cách đọc:** `Chat Trigger` nhận yêu cầu, `AI Agent` điều phối model và tool. `Simple Memory` giúp nhớ ngữ cảnh cùng phiên. `Data Table` giữ dữ kiện lâu dài như sở thích, còn các công cụ web lấy dữ liệu bên ngoài. Người học cần kiểm tra execution log để xem Agent đã thực sự gọi các công cụ hay chưa.

Một sơ đồ đẹp không bảo đảm quyền truy cập đã được bảo vệ. Nếu sử dụng nhiều người dùng, cần thêm `user_id` được xác thực và bộ lọc tại tầng lưu trữ trước khi đưa bất kỳ ký ức nào đến Agent. Các node đọc, thêm và cập nhật nên có mô tả rõ ý định và chỉ được nhận các tham số thuộc quyền người dùng hiện hành.

## 2. Vòng đời một ký ức qua nhiều phiên

```mermaid
sequenceDiagram
  participant U as Người dùng
  participant A as Luna AI Agent
  participant D as Data Tables
  U->>A: Hãy ghi nhớ: Tôi thích pizza
  A->>D: Get favorite_food
  D-->>A: Không tìm thấy
  A->>D: Insert favorite_food = pizza
  D-->>A: Thành công
  A-->>U: Đã lưu sở thích pizza
  Note over U,A: Người dùng mở phiên chat mới
  U->>A: Tôi thích món gì?
  A->>D: Get favorite_food
  D-->>A: pizza
  A-->>U: Bạn thích pizza
```

**Cách đọc:** Một thông tin chỉ trở thành bộ nhớ dài hạn khi thao tác ghi thành công. Tạo phiên chat mới không làm mất dữ liệu của bảng. Khi trả lời câu hỏi mới, Agent chủ động gọi `Get` để lấy dữ kiện cần thiết. Với sự kiện “Tôi ăn pizza hôm nay”, cần xác định đó có thực sự là sở thích bền vững hay chỉ là lời kể tình huống.

## 3. Bài tập áp dụng sơ đồ

Hãy tự vẽ thêm trường hợp “Tôi thích sushi hơn pizza” vào sơ đồ sequence. Luồng đúng phải tìm được bản ghi `favorite_food` hiện tại rồi gọi Update để thay giá trị mới. Không chèn một bản ghi `favorite_food` thứ hai nếu cần duy trì chỉ một sở thích đang hoạt động. Sau thao tác, mở phiên chat mới và kiểm tra dữ liệu xuất ra từ `Get Memories`.

Nếu hệ thống cần phục vụ nhiều tài khoản, hãy vẽ thêm một node `Authenticate User` trước khi `Get Memories`. Mọi truy vấn đến bảng phải được ràng buộc bằng định danh tin cậy. Không chấp nhận yêu cầu người dùng tự gõ một `user_id` tùy ý để truy xuất dữ liệu của người khác.

## 4. Kiểm tra sơ đồ trong trình xem Markdown

Với trình xem hỗ trợ Mermaid, các khối `mermaid` sẽ xuất hiện dưới dạng hình vẽ. Với trình xem chưa có Mermaid, chúng vẫn là mã sơ đồ có thể sao chép vào Mermaid Live Editor. Để sử dụng mà không phụ thuộc plugin, xem các sơ đồ có sẵn trong các bài 04, 05 và 09, vì những bài đó đã có lời giải thích đi kèm.
