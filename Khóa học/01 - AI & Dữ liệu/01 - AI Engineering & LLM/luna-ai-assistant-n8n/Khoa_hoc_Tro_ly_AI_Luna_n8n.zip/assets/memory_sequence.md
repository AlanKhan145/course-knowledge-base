# Sơ đồ luồng bộ nhớ dài hạn

```mermaid
sequenceDiagram
  participant U as Người dùng
  participant A as Luna AI Agent
  participant D as Data Tables
  U->>A: Hãy ghi nhớ: Tôi thích pizza
  A->>D: Get favorite_food
  D-->>A: Không tìm thấy
  A->>D: Insert favorite_food = pizza
  D-->>A: Thành công
  A-->>U: Đã lưu sở thích pizza
  Note over U,A: Người dùng mở phiên chat mới
  U->>A: Tôi thích món gì?
  A->>D: Get favorite_food
  D-->>A: pizza
  A-->>U: Bạn thích pizza
```
