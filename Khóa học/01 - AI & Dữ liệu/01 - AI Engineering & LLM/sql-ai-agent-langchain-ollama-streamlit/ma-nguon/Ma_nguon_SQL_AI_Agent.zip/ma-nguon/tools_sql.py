"""Bốn công cụ mà model được phép yêu cầu gọi."""
from langchain_core.tools import tool
from db_access import list_tables, describe_table, sample_table, execute_select


def make_sql_tools(db_path: str):
    @tool
    def list_database_tables(purpose: str) -> str:
        """Liệt kê tên tất cả bảng người dùng trong cơ sở dữ liệu SQL.
        purpose: giải thích ngắn gọn mục đích nghiệp vụ của thao tác."""
        return list_tables(db_path)

    @tool
    def describe_database_table(table: str, purpose: str) -> str:
        """Đọc cấu trúc cột, kiểu dữ liệu và khóa ngoại của một bảng.
        table: tên bảng cần đọc; purpose: mục đích ngắn gọn."""
        return describe_table(db_path, table)

    @tool
    def sample_database_table(table: str, purpose: str, n_rows: int = 5) -> str:
        """Xem 1–10 dòng dữ liệu mẫu để hiểu ý nghĩa giá trị trong bảng.
        table: tên bảng; purpose: mục đích; n_rows: số dòng mẫu."""
        return sample_table(db_path, table, n_rows)

    @tool
    def execute_sql_query(sql: str, purpose: str) -> str:
        """Chạy duy nhất truy vấn SQLite SELECT/CTE chỉ đọc, tối đa 50 dòng trả về.
        sql: câu SQL hợp lệ; purpose: mục đích nghiệp vụ ngắn gọn."""
        return execute_select(db_path, sql)

    return [list_database_tables, describe_database_table,
            sample_database_table, execute_sql_query]
