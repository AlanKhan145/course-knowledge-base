"""Khởi tạo DB SQLite thương mại điện tử bằng dữ liệu giả định, có thể chạy lại."""
import sqlite3
from pathlib import Path

PATH = Path(__file__).resolve().parent / "ecommerce.db"

DDL = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
    price REAL NOT NULL CHECK(price>=0), stock INTEGER NOT NULL CHECK(stock>=0)
);
CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, city TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL,
    order_date TEXT NOT NULL, status TEXT NOT NULL,
    FOREIGN KEY(customer_id) REFERENCES customers(id)
);
CREATE TABLE IF NOT EXISTS order_items (
    order_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity INTEGER NOT NULL,
    unit_price REAL NOT NULL,
    PRIMARY KEY(order_id, product_id),
    FOREIGN KEY(order_id) REFERENCES orders(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
);
"""
PRODUCTS = [
    (1, "Mỳ udon", "Thực phẩm", 42000, 30),
    (2, "Mỳ ramen", "Thực phẩm", 50000, 15),
    (3, "Trà xanh", "Đồ uống", 25000, 22),
    (4, "Cà phê rang xay", "Đồ uống", 90000, 18),
    (5, "Nồi inox", "Gia dụng", 380000, 7),
    (6, "Chảo chống dính", "Gia dụng", 290000, 12),
    (7, "Gạo thơm", "Thực phẩm", 180000, 60),
    (8, "Dầu ô liu", "Thực phẩm", 155000, 0),
    (9, "Bánh quy", "Thực phẩm", 35000, 20),
    (10, "Bình giữ nhiệt", "Gia dụng", 240000, 9),
]
CUSTOMERS = [
    (1, "Nguyễn An", "Hà Nội"), (2, "Trần Bình", "Đà Nẵng"),
    (3, "Lê Chi", "Hà Nội"), (4, "Phạm Dung", "TP.HCM"),
    (5, "Hoàng Em", "Huế"),
]
ORDERS = [
    (101, 1, "2026-09-01", "completed"),
    (102, 2, "2026-09-05", "completed"),
    (103, 1, "2026-09-10", "completed"),
    (104, 3, "2026-09-13", "pending"),
    (105, 4, "2026-09-16", "completed"),
    (106, 1, "2026-09-20", "completed"),
    (107, 2, "2026-09-23", "pending"),
    (108, 5, "2026-09-28", "completed"),
    (109, 1, "2026-10-02", "completed"),
    (110, 3, "2026-10-07", "cancelled"),
    (111, 4, "2026-10-13", "completed"),
    (112, 1, "2026-10-20", "pending"),
]
ITEMS = [
    (101, 1, 2, 42000), (101, 3, 1, 25000),
    (102, 2, 1, 50000), (102, 5, 1, 380000),
    (103, 7, 1, 180000), (104, 4, 1, 90000),
    (105, 6, 1, 290000), (106, 1, 3, 42000),
    (107, 10, 1, 240000), (108, 9, 2, 35000),
    (109, 2, 2, 50000), (109, 3, 2, 25000),
    (110, 8, 1, 155000), (111, 5, 1, 380000),
    (112, 1, 1, 42000), (112, 7, 1, 180000),
]

def main():
    with sqlite3.connect(PATH) as con:
        con.executescript(DDL)
        if con.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
            con.executemany("INSERT INTO products VALUES (?,?,?,?,?)", PRODUCTS)
        if con.execute("SELECT COUNT(*) FROM customers").fetchone()[0] == 0:
            con.executemany("INSERT INTO customers VALUES (?,?,?)", CUSTOMERS)
        if con.execute("SELECT COUNT(*) FROM orders").fetchone()[0] == 0:
            con.executemany("INSERT INTO orders VALUES (?,?,?,?)", ORDERS)
        if con.execute("SELECT COUNT(*) FROM order_items").fetchone()[0] == 0:
            con.executemany("INSERT INTO order_items VALUES (?,?,?,?)", ITEMS)
    print(f"Đã chuẩn bị dữ liệu giả định tại: {PATH}")

if __name__ == "__main__":
    main()
