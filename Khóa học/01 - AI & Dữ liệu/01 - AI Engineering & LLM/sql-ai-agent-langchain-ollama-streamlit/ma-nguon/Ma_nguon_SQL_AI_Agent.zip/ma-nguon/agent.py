"""Vòng lặp tool-calling thủ công để quan sát luồng điều khiển của AI Agent."""
from datetime import date
from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage

SYSTEM_PROMPT = """Bạn là trợ lý phân tích dữ liệu thương mại điện tử.
Ngày hiện tại trên máy chủ: {today}.
Chỉ dùng các công cụ SQL được cung cấp. Khi chưa biết schema hãy liệt kê bảng,
đọc cấu trúc, xem mẫu rồi mới viết SELECT. Không suy đoán dữ liệu không truy vấn được.
Chỉ đọc: không tạo, xóa, sửa dữ liệu hoặc thay đổi schema.
Khi một truy vấn lỗi, dùng thông báo lỗi để sửa truy vấn hoặc nêu rõ giới hạn.
Nếu câu hỏi không đủ rõ, hỏi lại một câu phù hợp.
Không đưa ra những thông tin nhạy cảm nằm ngoài nhu cầu câu hỏi.
Giải thích kết quả bằng tiếng Việt tự nhiên, Markdown; ưu tiên bảng khi cần.
Không trình bày suy luận nội bộ; purpose trong tool là nhãn hành động ngắn gọn.
"""


def new_history():
    return [SystemMessage(content=SYSTEM_PROMPT.format(today=date.today().isoformat()))]


def ask_agent(question: str, history: list, model, tools: list,
              max_steps: int = 8, on_tool=None) -> str:
    """Sửa history tại chỗ; tối đa max_steps vòng tương tác model-công cụ."""
    by_name = {t.name: t for t in tools}
    history.append(HumanMessage(content=question))
    for _ in range(max_steps):
        answer = model.invoke(history)
        history.append(answer)
        calls = getattr(answer, "tool_calls", []) or []
        if not calls:
            return str(answer.content)
        for call in calls:
            name, args, call_id = call["name"], call.get("args", {}), call["id"]
            if on_tool:
                on_tool(name, args.get("purpose", "Thao tác dữ liệu"))
            try:
                tool = by_name.get(name)
                if tool is None:
                    raise ValueError(f"Không có công cụ {name}")
                result = tool.invoke(args)
            except Exception as exc:
                result = f"TOOL_ERROR: {type(exc).__name__}: {exc}"
            history.append(ToolMessage(content=str(result), tool_call_id=call_id))
    # Không để model tiếp tục vô hạn nếu bị lặp hoặc có lỗi.
    return "Không thể hoàn tất trong giới hạn bước. Hãy thu hẹp câu hỏi hoặc thử lại."
