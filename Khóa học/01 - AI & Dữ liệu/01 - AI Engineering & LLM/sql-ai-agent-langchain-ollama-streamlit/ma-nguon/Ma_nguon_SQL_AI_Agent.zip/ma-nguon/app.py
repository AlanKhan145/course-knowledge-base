"""Giao diện Streamlit dành cho AI Agent SQL."""
import os
from pathlib import Path
import streamlit as st
from dotenv import load_dotenv

from agent import ask_agent, new_history
from db_access import list_tables, readonly_connection
from model_factory import create_model
from tools_sql import make_sql_tools

load_dotenv()
HERE = Path(__file__).resolve().parent
DB_PATH = str((HERE / os.getenv("DATABASE_PATH", "ecommerce.db")).resolve())
MAX_STEPS = max(1, min(int(os.getenv("MAX_AGENT_STEPS", "8")), 20))

st.set_page_config(page_title="SQL Agent · Local First", page_icon="🗃️", layout="wide")
st.title("🗃️ Hỏi đáp cơ sở dữ liệu bằng AI")
st.caption("LangChain + Ollama/Groq + SQLite · chỉ đọc")

@st.cache_resource(show_spinner=False)
def components(db_path: str, provider: str, model_name: str):
    return create_model().bind_tools(make_sql_tools(db_path)), make_sql_tools(db_path)

with st.sidebar:
    st.header("Cơ sở dữ liệu")
    st.code(DB_PATH)
    st.caption("Dữ liệu mẫu được tạo riêng cho bài học, không phải dữ liệu thật.")
    if Path(DB_PATH).exists():
        st.metric("Dung lượng (KB)", f"{Path(DB_PATH).stat().st_size / 1024:.1f}")
        try:
            for table in __import__('json').loads(list_tables(DB_PATH)):
                with readonly_connection(DB_PATH) as con:
                    n = con.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
                st.write(f"`{table}` — {n} dòng")
        except Exception as exc:
            st.warning(str(exc))
    else:
        st.error("Chưa có ecommerce.db. Chạy: python seed_data.py")
    if st.button("Xóa lịch sử phiên"):
        st.session_state.pop("chat_history", None)
        st.session_state.pop("model_history", None)
        st.rerun()

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "model_history" not in st.session_state:
    st.session_state.model_history = new_history()

for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

question = st.chat_input("Ví dụ: Khách hàng nào có nhiều đơn hàng nhất?")
if question:
    st.session_state.chat_history.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)
    with st.chat_message("assistant"):
        if not Path(DB_PATH).exists():
            response = "Chưa có cơ sở dữ liệu. Hãy chạy `python seed_data.py` rồi tải lại trang."
        else:
            try:
                model, tools = components(DB_PATH,
                                          os.getenv("MODEL_PROVIDER", "ollama"),
                                          os.getenv("MODEL_NAME", "qwen2.5:7b"))
                with st.status("Đang phân tích và truy vấn...", expanded=False) as status:
                    def report(name, purpose):
                        status.write(f"`{name}` · {purpose}")
                    response = ask_agent(question, st.session_state.model_history,
                                         model, tools, MAX_STEPS, report)
                    status.update(label="Hoàn tất", state="complete")
            except Exception as exc:
                response = f"Không thể hoàn tất: `{type(exc).__name__}` — {exc}"
        st.markdown(response)
    st.session_state.chat_history.append({"role": "assistant", "content": response})
