"""Truy cập SQLite chỉ đọc. Các giới hạn bổ sung phù hợp bài lab, không phải sandbox tuyệt đối."""
import json
import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path

IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
MAX_ROWS = 50


@contextmanager
def readonly_connection(db_path: str):
    db = Path(db_path).resolve()
    if not db.is_file():
        raise FileNotFoundError(f"Chưa có database: {db}. Hãy chạy seed_data.py")
    # mode=ro ngăn ghi ở mức SQLite; query_only bổ sung lớp phòng vệ.
    con = sqlite3.connect(db.as_uri() + "?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA query_only = ON")
    # Dừng truy vấn quá tốn tài nguyên theo số instruction của SQLite.
    checks = 0

    def progress():
        nonlocal checks
        checks += 1
        return 1 if checks > 2000 else 0

    con.set_progress_handler(progress, 1000)
    try:
        yield con
    finally:
        con.close()


def list_tables(db_path: str) -> str:
    with readonly_connection(db_path) as con:
        rows = con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%' ORDER BY name"
        ).fetchall()
    return json.dumps([row["name"] for row in rows], ensure_ascii=False)


def _safe_table(con: sqlite3.Connection, name: str) -> str:
    if not IDENTIFIER.fullmatch(name):
        raise ValueError("Tên bảng không hợp lệ")
    exists = con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (name,),
    ).fetchone()
    if not exists:
        raise ValueError(f"Không tìm thấy bảng: {name}")
    return name


def describe_table(db_path: str, table: str) -> str:
    with readonly_connection(db_path) as con:
        name = _safe_table(con, table)
        columns = con.execute(f'PRAGMA table_info("{name}")').fetchall()
        foreign_keys = con.execute(f'PRAGMA foreign_key_list("{name}")').fetchall()
    data = {"columns": [dict(row) for row in columns],
            "foreign_keys": [dict(row) for row in foreign_keys]}
    return json.dumps(data, ensure_ascii=False, default=str)


def sample_table(db_path: str, table: str, n_rows: int = 5) -> str:
    n_rows = max(1, min(int(n_rows), 10))
    with readonly_connection(db_path) as con:
        name = _safe_table(con, table)
        rows = con.execute(f'SELECT * FROM "{name}" LIMIT ?', (n_rows,)).fetchall()
    return json.dumps([dict(row) for row in rows], ensure_ascii=False, default=str)


def execute_select(db_path: str, sql: str) -> str:
    # Kiểm tra cú pháp sơ bộ, không phải bảo đảm an toàn duy nhất.
    if not re.match(r"^\s*(SELECT|WITH)\b", sql, re.IGNORECASE):
        raise ValueError("Chỉ cho phép câu truy vấn SELECT/CTE chỉ đọc")
    with readonly_connection(db_path) as con:
        cur = con.execute(sql)  # Một statement duy nhất, tham số do agent xây dựng.
        if cur.description is None:
            raise ValueError("Truy vấn không trả về bảng kết quả")
        columns = [description[0] for description in cur.description]
        fetched = cur.fetchmany(MAX_ROWS + 1)
    return json.dumps({
        "columns": columns,
        "rows": [list(row) for row in fetched[:MAX_ROWS]],
        "truncated": len(fetched) > MAX_ROWS,
        "max_rows": MAX_ROWS,
    }, ensure_ascii=False, default=str)
