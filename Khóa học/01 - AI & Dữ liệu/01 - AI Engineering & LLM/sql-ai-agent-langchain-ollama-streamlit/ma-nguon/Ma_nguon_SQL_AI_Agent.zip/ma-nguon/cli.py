"""Chạy agent trong terminal với log Rich thay vì Streamlit."""
import os
from dotenv import load_dotenv
from rich.console import Console
from rich.panel import Panel
from agent import ask_agent, new_history
from model_factory import create_model
from tools_sql import make_sql_tools

load_dotenv()
console = Console()
tools = make_sql_tools(os.getenv("DATABASE_PATH", "ecommerce.db"))
model = create_model().bind_tools(tools)
history = new_history()
console.print("[bold]SQL Agent CLI[/bold] — gõ 'exit' để thoát")
while True:
    question = console.input("\n[cyan]Bạn:[/cyan] ").strip()
    if question.lower() in {"exit", "quit"}:
        break
    if not question:
        continue
    def log(name, purpose):
        console.print(f"[dim]Tool: {name} · {purpose}[/dim]")
    try:
        answer = ask_agent(question, history, model, tools,
                           int(os.getenv("MAX_AGENT_STEPS", "8")), log)
        console.print(Panel(answer, title="Agent"))
    except Exception as exc:
        console.print(f"[red]Lỗi: {exc}[/red]")
