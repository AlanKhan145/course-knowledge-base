"""Chọn Chat Model theo cấu hình, không khóa cứng một nhà cung cấp."""
import os
from dotenv import load_dotenv

load_dotenv()


def create_model():
    provider = os.getenv("MODEL_PROVIDER", "ollama").strip().lower()
    if provider == "ollama":
        from langchain_ollama import ChatOllama
        return ChatOllama(
            model=os.getenv("MODEL_NAME", "qwen2.5:7b"),
            temperature=0,
        )
    if provider == "groq":
        from langchain_groq import ChatGroq
        if not os.getenv("GROQ_API_KEY"):
            raise ValueError("Thiếu GROQ_API_KEY trong môi trường/.env")
        return ChatGroq(
            model=os.getenv("MODEL_NAME", "llama-3.3-70b-versatile"),
            temperature=0,
        )
    raise ValueError("MODEL_PROVIDER chỉ nhận 'ollama' hoặc 'groq'")
