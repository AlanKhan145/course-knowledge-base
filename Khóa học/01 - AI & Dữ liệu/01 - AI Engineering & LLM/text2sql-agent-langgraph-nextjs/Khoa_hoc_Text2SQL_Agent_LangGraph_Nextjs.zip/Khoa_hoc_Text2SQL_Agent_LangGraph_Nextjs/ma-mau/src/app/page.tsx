"use client";
import { useState, type FormEvent } from "react";

type ChatTurn = { role: "user" | "assistant"; content: string };

export default function Home() {
  const [inputMessage, setInputMessage] = useState("");
  const [messages, setMessages] = useState<ChatTurn[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const content = inputMessage.trim();
    if (!content || isLoading) return;
    const nextMessages: ChatTurn[] = [...messages, { role: "user", content }];
    setMessages(nextMessages);
    setInputMessage("");
    setError("");
    setIsLoading(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages }),
      });
      const payload: { answer?: string; error?: string } = await response.json();
      if (!response.ok || !payload.answer) {
        throw new Error(payload.error ?? "Không có câu trả lời.");
      }
      setMessages((old) => [...old, { role: "assistant", content: payload.answer! }]);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Có lỗi xảy ra.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col gap-6 p-6">
      <header>
        <h1 className="text-3xl font-bold">Text-to-SQL Agent</h1>
        <p className="mt-2 text-sm text-slate-500">Hỏi cơ sở dữ liệu bằng tiếng Việt</p>
      </header>
      <section aria-live="polite" className="flex flex-1 flex-col gap-4 rounded-xl border p-4">
        {messages.length === 0 && <p>Ví dụ: Có bao nhiêu khách hàng?</p>}
        {messages.map((message, index) => (
          <div key={`${message.role}-${index}`} className={`rounded-lg p-3 ${
            message.role === "user" ? "bg-blue-100 text-slate-900" : "bg-slate-100 text-slate-900"
          }`}>
            <strong>{message.role === "user" ? "Bạn" : "Agent"}</strong>
            <p className="whitespace-pre-wrap">{message.content}</p>
          </div>
        ))}
        {isLoading && <p>Agent đang xử lý…</p>}
        {error && <p role="alert" className="text-red-600">{error}</p>}
      </section>
      <form onSubmit={sendMessage} className="flex gap-2">
        <input aria-label="Tin nhắn" value={inputMessage} disabled={isLoading}
          onChange={(e) => setInputMessage(e.target.value)}
          placeholder="Nhập câu hỏi SQL bằng ngôn ngữ tự nhiên…"
          className="min-w-0 flex-1 rounded-lg border px-4 py-3" />
        <button type="submit" disabled={isLoading || !inputMessage.trim()}
          className="rounded-lg bg-blue-700 px-5 py-3 text-white disabled:opacity-50">
          {isLoading ? "Đang tải…" : "Gửi"}
        </button>
      </form>
    </main>
  );
}
