import "server-only";
import sqlite3 from "sqlite3";

// Chỉ dùng trong môi trường phát triển một tiến trình Node.js.
type Row = Record<string, unknown>;
let connection: Promise<sqlite3.Database> | undefined;

function run(db: sqlite3.Database, sql: string, params: unknown[] = []): Promise<void> {
  return new Promise((resolve, reject) => {
    db.run(sql, params, (error) => (error ? reject(error) : resolve()));
  });
}

function all(db: sqlite3.Database, sql: string): Promise<Row[]> {
  return new Promise((resolve, reject) => {
    db.all(sql, (error, rows: Row[]) => (error ? reject(error) : resolve(rows)));
  });
}

async function createDatabase(): Promise<sqlite3.Database> {
  const db = new sqlite3.Database(":memory:");
  await run(db, "PRAGMA foreign_keys = ON");
  await run(db, `CREATE TABLE "customers" (
    "id" INTEGER PRIMARY KEY,
    "email" TEXT NOT NULL UNIQUE,
    "name" TEXT NOT NULL
  )`);
  await run(db, `CREATE TABLE "orders" (
    "id" INTEGER PRIMARY KEY,
    "customer_id" INTEGER NOT NULL,
    "total" REAL NOT NULL,
    FOREIGN KEY ("customer_id") REFERENCES "customers" ("id")
  )`);
  const names = [
    "Lucas Bill", "Mai Nguyen", "An Tran", "Linh Pham", "Minh Ho",
    "Quynh Le", "Tuan Dao", "Hoa Do", "Nhi Vo", "Dat Bui"
  ];
  for (let i = 0; i < names.length; i++) {
    await run(db, `INSERT INTO "customers" ("id", "email", "name") VALUES (?, ?, ?)`,
      [i + 1, `customer${i + 1}@example.com`, names[i]]);
  }
  const orderCustomerIds = [1, 1, 1, 1, 2, 2, 3, 3, 4, 5, 6, 7, 8, 10];
  for (let i = 0; i < orderCustomerIds.length; i++) {
    await run(db, `INSERT INTO "orders" ("id", "customer_id", "total") VALUES (?, ?, ?)`,
      [i + 1, orderCustomerIds[i], 100 + i * 10]);
  }
  // Tầng cơ sở dữ liệu, không chỉ prompt, chặn mọi tác vụ ghi.
  await run(db, "PRAGMA query_only = ON");
  return db;
}

export function getDatabase(): Promise<sqlite3.Database> {
  connection ??= createDatabase().catch((err) => {
    connection = undefined;
    throw err;
  });
  return connection;
}

/** Hàng rào demo: SELECT/WITH duy nhất, không đa câu lệnh; SQLite query_only là lớp chặn chính. */
export async function executeReadOnly(sql: string): Promise<Row[]> {
  const query = sql.trim();
  if (!/^(SELECT|WITH)\b/i.test(query)) {
    throw new Error("Chỉ cho phép truy vấn đọc SELECT/WITH.");
  }
  if (/;|--|\/\*|\*\//.test(query)) {
    throw new Error("Không chấp nhận nhiều lệnh hoặc SQL comment.");
  }
  if (/\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|ATTACH|DETACH|PRAGMA|REPLACE|VACUUM)\b/i.test(query)) {
    throw new Error("Truy vấn chứa từ khóa bị chặn.");
  }
  const db = await getDatabase();
  const rows = await all(db, query);
  if (rows.length > 100) throw new Error("Giới hạn phản hồi demo: tối đa 100 hàng.");
  return rows;
}
