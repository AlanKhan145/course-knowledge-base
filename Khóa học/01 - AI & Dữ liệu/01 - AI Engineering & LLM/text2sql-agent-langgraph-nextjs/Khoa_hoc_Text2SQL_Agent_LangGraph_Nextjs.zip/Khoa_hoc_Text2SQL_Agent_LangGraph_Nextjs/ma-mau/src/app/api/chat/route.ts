import { NextResponse } from "next/server";
import { z } from "zod";
import { askAgent } from "@/lib/agent";

export const runtime = "nodejs";

const RequestSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string().trim().min(1).max(2000),
  })).min(1).max(20),
});

export async function POST(request: Request) {
  try {
    const raw: unknown = await request.json();
    const parsed = RequestSchema.safeParse(raw);
    if (!parsed.success || parsed.data.messages.at(-1)?.role !== "user") {
      return NextResponse.json({ error: "Lịch sử hội thoại không hợp lệ." }, { status: 400 });
    }
    const answer = await askAgent(parsed.data.messages);
    return NextResponse.json({ answer });
  } catch (error) {
    console.error("Agent request failed:", error);
    return NextResponse.json({ error: "Không thể xử lý câu hỏi lúc này." }, { status: 500 });
  }
}
