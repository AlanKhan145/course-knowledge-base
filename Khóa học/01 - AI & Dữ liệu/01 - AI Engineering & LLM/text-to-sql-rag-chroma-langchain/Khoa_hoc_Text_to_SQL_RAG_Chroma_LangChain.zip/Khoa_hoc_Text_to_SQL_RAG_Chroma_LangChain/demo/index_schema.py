from pathlib import Path
import sqlite3
import shutil
from langchain_core.documents import Document
from langchain_chroma import Chroma
from langchain_huggingface import HuggingFaceEmbeddings

BASE = Path(__file__).resolve().parent
DB = BASE / 'data' / 'recipes.sqlite3'
INDEX = BASE / 'data' / 'chroma'
EMBEDDING_MODEL = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'

if not DB.exists():
    raise SystemExit('Chưa có DB. Chạy python init_db.py trước.')

conn = sqlite3.connect(DB)
conn.row_factory = sqlite3.Row
names = [r['name'] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
docs = []
for name in names:
    # Chỉ dùng tên bảng từ metadata SQLite, không lấy từ user.
    columns = conn.execute(f'PRAGMA table_info("{name}")').fetchall()
    fks = conn.execute(f'PRAGMA foreign_key_list("{name}")').fetchall()
    cols = ', '.join(f'{c[1]} {c[2]}' for c in columns)
    rels = '; '.join(f'{fk[3]} -> {fk[2]}.{fk[4]}' for fk in fks) or 'không có khóa ngoại khai báo'
    descr = f'Bảng {name}. Cột: {cols}. Quan hệ khóa ngoại: {rels}.'
    docs.append(Document(page_content=descr, metadata={'table': name}))
conn.close()

# Đây là bản demo: xây lại index để tránh tích lũy vector trùng lặp.
if INDEX.exists():
    shutil.rmtree(INDEX)
emb = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
Chroma.from_documents(
    documents=docs,
    embedding=emb,
    ids=[f'schema_{d.metadata["table"]}' for d in docs],
    collection_name='recipe_schema',
    persist_directory=str(INDEX),
)
print(f'Đã index {len(docs)} bảng trong {INDEX}')
