# Demo Text-to-SQL cho dữ liệu món ăn

Prototype minh họa gồm 3 bảng SQLite, Chroma để index schema, một LLM tạo SQL, API FastAPI, UI Streamlit.

## Các lệnh chạy

```bash
cd demo
python -m venv .venv
# Windows: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
# Sao chép .env.example thành .env rồi điền key/model hợp lệ
python init_db.py
python index_schema.py
uvicorn api:app --reload
# terminal khác:
streamlit run ui.py
```

Đọc `10-lab-xay-dung-chatbot.md` để xem checklist và kiểm thử. **Không chạy trên cơ sở dữ liệu sản xuất.** `.env` chứa secrets không được tải lên kho công khai. Bản demo có các giới hạn cố ý: không có đăng nhập/phân quyền, rate limiting, resource isolation, giới hạn kết quả 50 hàng nhưng không bảo đảm giới hạn chi phí CPU tuyệt đối. Không cung cấp endpoint này ra Internet.

**Lưu ý tính đúng:** `sqlglot` kiểm tra cấu trúc SELECT, whitelist bảng và tập hàm hạn chế; đây là minh họa học thuật. Quyền DB riêng và các bộ kiểm soát sản xuất vẫn cần thiết. Tải model embeddings lần đầu có thể cần kết nối Internet và thời gian xử lý tùy máy.
