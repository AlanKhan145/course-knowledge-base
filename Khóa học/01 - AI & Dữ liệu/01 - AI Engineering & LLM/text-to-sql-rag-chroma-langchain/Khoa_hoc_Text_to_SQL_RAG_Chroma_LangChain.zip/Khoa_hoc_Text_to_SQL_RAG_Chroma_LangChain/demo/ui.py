import requests
import streamlit as st

st.set_page_config(page_title='Text-to-SQL Demo', page_icon='🍜')
st.title('🍜 Chatbot hỏi dữ liệu món ăn')
st.caption('Prototype học tập: SQLite + Chroma + LangChain + FastAPI + Streamlit')
if 'messages' not in st.session_state:
    st.session_state.messages = []
for message in st.session_state.messages:
    with st.chat_message(message['role']):
        st.write(message['content'])
        if message.get('rows') is not None:
            st.dataframe(message['rows'], use_container_width=True)
            with st.expander('SQL đã sử dụng'):
                st.code(message.get('sql',''), language='sql')
question = st.chat_input('Ví dụ: món nào có mì và nấu không quá 20 phút?')
if question:
    st.session_state.messages.append({'role':'user', 'content':question})
    with st.chat_message('user'):
        st.write(question)
    with st.chat_message('assistant'):
        with st.spinner('Đang kiểm tra dữ liệu...'):
            try:
                response = requests.post('http://127.0.0.1:8000/ask', json={'question':question}, timeout=120)
                response.raise_for_status()
                result = response.json()
                st.write(result['answer'])
                st.dataframe(result['rows'], use_container_width=True)
                with st.expander('SQL đã sử dụng'):
                    st.code(result['sql'], language='sql')
                st.session_state.messages.append({'role':'assistant','content':result['answer'], 'rows':result['rows'], 'sql':result['sql']})
            except requests.RequestException:
                st.error('Không kết nối được API hoặc yêu cầu bị từ chối. Kiểm tra FastAPI và cấu hình model.')
