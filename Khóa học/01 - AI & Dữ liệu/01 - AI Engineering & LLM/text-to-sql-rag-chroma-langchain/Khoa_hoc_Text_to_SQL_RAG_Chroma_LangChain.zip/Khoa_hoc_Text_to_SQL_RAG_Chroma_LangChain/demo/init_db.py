from pathlib import Path
import sqlite3

BASE = Path(__file__).resolve().parent
DB = BASE / 'data' / 'recipes.sqlite3'
DB.parent.mkdir(parents=True, exist_ok=True)
conn = sqlite3.connect(DB)
conn.execute('PRAGMA foreign_keys=ON')
conn.executescript('''
DROP TABLE IF EXISTS dish_ingredients;
DROP TABLE IF EXISTS ingredients;
DROP TABLE IF EXISTS dishes;
CREATE TABLE dishes (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  cooking_minutes INTEGER NOT NULL,
  category TEXT NOT NULL
);
CREATE TABLE ingredients (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  allergen_group TEXT
);
CREATE TABLE dish_ingredients (
  dish_id INTEGER NOT NULL REFERENCES dishes(id),
  ingredient_id INTEGER NOT NULL REFERENCES ingredients(id),
  amount TEXT,
  PRIMARY KEY(dish_id, ingredient_id)
);
INSERT INTO dishes VALUES
  (1, 'Mì rau', 15, 'món nước'),
  (2, 'Mì hải sản', 25, 'món nước'),
  (3, 'Salad trứng', 10, 'món nguội'),
  (4, 'Cơm gà', 35, 'món cơm'),
  (5, 'Mì nấm', 20, 'món khô');
INSERT INTO ingredients VALUES
  (1, 'mì', 'gluten'), (2, 'rau', NULL),
  (3, 'tôm', 'seafood'), (4, 'trứng', 'egg'),
  (5, 'gà', NULL), (6, 'cơm', NULL), (7, 'nấm', NULL);
INSERT INTO dish_ingredients VALUES
  (1,1,'100g'),(1,2,'50g'),
  (2,1,'100g'),(2,3,'80g'),
  (3,2,'50g'),(3,4,'2 quả'),
  (4,5,'100g'),(4,6,'150g'),
  (5,1,'100g'),(5,7,'80g');
''')
conn.commit()
conn.close()
print(f'Đã tạo database demo: {DB}')
