# Vowels /ɑː/ and /ʌ/

- **Khóa học:** Tự học phát âm tiếng Anh — Nền tảng cho kỹ năng đọc
- **Module:** 02. Nguyên âm đơn
- **Bài nguồn:** Unit 04
- **Trang nguồn theo mục lục:** 35
- **Loại:** lesson

> **Phạm vi trích xuất:** ảnh anh cung cấp hiện có **bìa và mục lục**. Vì chưa có ảnh nội dung bên trong từng Unit, file này là **lesson outline được thiết kế theo đúng chủ đề trong mục lục**, không phải bản chép nội dung chi tiết của sách.

## Mục tiêu học tập

- Phân biệt /ɑː/ và /ʌ/ theo vị trí miệng và độ dài.
- Luyện nghe – nói với các từ dễ nhầm.
- Nhận diện các kiểu chữ viết có thể tạo ra hai âm này.

## Nội dung trọng tâm

- Nhận diện âm hoặc quy tắc mục tiêu của bài.
- Quan sát khẩu hình, vị trí lưỡi/môi và luồng hơi khi phù hợp.
- Phân biệt với âm/quy tắc dễ nhầm.
- Luyện từ đơn → cụm từ → câu ngắn → đoạn đọc.

## Quy trình luyện tập

1. **Nhận diện:** đọc ký hiệu phiên âm và nghe/nhận biết âm mục tiêu.
2. **Khẩu hình:** luyện chậm để đặt đúng môi, lưỡi và hàm.
3. **Tương phản:** luyện các cặp từ hoặc trường hợp dễ nhầm.
4. **Ứng dụng:** đọc từ, cụm từ và câu.
5. **Tự kiểm tra:** thu âm, nghe lại và ghi lỗi.

## Bài tập tự luyện

1. Ghi 5–10 từ có chứa âm/quy tắc mục tiêu.
2. Phân loại từ theo cách phát âm hoặc vị trí âm.
3. Đọc mỗi từ 3 lần: chậm, bình thường, trong câu.
4. Thu âm một lần và tự đánh dấu lỗi cần sửa.

## Ghi chú sau khi học

- Ngày học:
- Mức độ tự tin: /5
- Từ/âm còn khó:
- Câu hỏi cần làm rõ:
- Bài cần ôn lại:
