# D4 — Sound pairs

- **Module:** Module 07 — Reference & Assessment
- **Loại:** Reference
- **Mục đích:** Bảng các cặp âm

## 1. Cách sử dụng
Dùng tài liệu này như trang tra cứu trong quá trình học các bài 01–60.

## 2. Nội dung cần bổ sung
Ảnh hiện tại chỉ hiển thị tên mục **Sound pairs**, chưa có các trang nội dung bên trong. Khi có ảnh/PDF tương ứng, phần này có thể được biên soạn thành tài liệu tra cứu đầy đủ.

## 3. Ghi chú người học
- Khái niệm cần tra:
- Bài học liên quan:
- Ví dụ tự tạo:
