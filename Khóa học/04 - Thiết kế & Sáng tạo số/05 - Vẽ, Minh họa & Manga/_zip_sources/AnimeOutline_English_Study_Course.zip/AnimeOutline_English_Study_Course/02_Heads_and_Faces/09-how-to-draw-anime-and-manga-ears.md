# 13. Anime and Manga Ears

> **Module:** 02 Heads & Faces  
> **Level:** Beginner  
> **Suggested practice:** 25–45 minutes  
> **Original source:** [Anime and Manga Ears](https://www.animeoutline.com/how-to-draw-anime-and-manga-ears/) · AnimeOutline

## Learning objective

Use simple ear silhouettes and landmarks at several angles.

## Core principle

A strong drawing is easier to edit when large masses, directional guides, and relationships are established before any fine rendering. For **anime and manga ears**, treat each visible line as evidence of an underlying form or a deliberate graphic design choice. Begin lightly, compare against a reference, and separate the *rough construction* from the *refined final drawing*.

The instructions below are an **independently written practice companion**, not a transcription or complete substitute for the original tutorial. Follow the site for its specific demonstrations and step sequences.

## Guided workshop

1. **Locate the ear on the side plane of the head.** After the step, compare the silhouette and relative placement to your reference.
2. **Block the outer ear contour before the inner folds.** After the step, compare the silhouette and relative placement to your reference.
3. **Simplify inner marks according to the style.** After the step, compare the silhouette and relative placement to your reference.
4. **Check vertical position against eyebrow and nose landmarks.** After the step, compare the silhouette and relative placement to your reference.

## Visual reference

![Original explanatory diagram for 02_Heads_and_Faces](../assets/01_head_construction.svg)

**Original website illustrations:** Open the tutorial link above to view the creator’s step-by-step images. The source artwork is not mirrored in this archive.

## Practice assignment

**Main exercise:** Draw six small ear studies in front, side, and three-quarter views.

- **Warm-up (5 min):** Draw several quick studies using only large shapes and gesture lines.
- **Construction (10–15 min):** Produce a rough version with visible guides and a consistent reference.
- **Refinement (10–15 min):** Correct the largest issues, remove unnecessary guides, and strengthen important contours.
- **Review (5 min):** Compare both stages, write down two improvements and one point to practice again.

## Common pitfall

**Watch out for:** Over-detailing the ear until it competes with the face.

Correct the issue in the rough phase rather than hiding it with extra contour lines or shading. A useful test is to shrink your drawing to thumbnail size; major shapes should remain intelligible.

## Self-check

- [ ] I built and verified the main shape before adding fine detail.
- [ ] My landmarks, overlaps, or perspective cues are internally consistent.
- [ ] I can name the specific visual decision that makes this study successful.
- [ ] I compared the rough sketch and the finished version.
- [ ] I opened the original illustrated tutorial to check its examples.

## Source and image rights

- **Author/site:** AnimeOutline — https://www.animeoutline.com/how-to-draw-anime-and-manga-ears/
- **Study note:** Newly written English educational companion prepared 2026-10-29.
- **Illustration:** The locally referenced SVG is an original explanatory schematic. Website art remains the property of the original rights holder and is not redistributed here.
