# VR Development — Module 02: Events and Interactions

## Giới thiệu

Module này tập trung vào **sự kiện và tương tác trong môi trường VR** trên Unity: phản hồi bằng âm thanh/haptics, kích hoạt vật thể, interactor gần/xa, giao diện người dùng, bài thực hành vẽ 3D và kiểm thử trên phần cứng XR.

Các tài liệu được biên soạn **bằng tiếng Việt**, có giải thích, bảng đối chiếu, ví dụ, sơ đồ Mermaid, bài tập thực hành và câu hỏi ôn tập. Chúng là **bài học tự biên soạn**, không phải bản dịch đầy đủ transcript hay tài liệu chính thức của Unity. Phiên bản mục lục được ghi nhận trong tài liệu đầu vào là **Unity 6.3**; giao diện hoặc package trong dự án thực tế có thể khác.

## Lộ trình học

```mermaid
flowchart TD
    A[2.1 Âm thanh và haptics] --> B[2.2 Activation events]
    B --> C[2.3 Near–Far / Ray Interactors]
    C --> D[2.4 Giao diện người dùng VR]
    D --> E[Challenge 2: Vẽ 3D]
    E --> F[Tổng quan phần cứng XR]
    F --> G[Lab 2: Dự án cá nhân]
    G --> H[Mission 2: Quiz ôn tập]
```

Lộ trình đi từ **phản hồi của một hành động** đến **tương tác có điều kiện**, **thao tác ở nhiều khoảng cách**, rồi **tích hợp thành một scene thử nghiệm**. Tài liệu phần cứng đặt trước lab để người học biết những yếu tố cần kiểm tra trên HMD.

## Mục lục

| Thứ tự | Bài học | Trọng tâm |
| --- | --- | --- |
| 01 | [Audio and Haptics](001-2-1-audio-and-haptics.md) | Âm 2D/3D, Audio Source, Audio Listener, sự kiện phản hồi |
| 02 | [Activation Events](002-2-2-activation-events-activation-remote-lightsource.md) | Remote bật/tắt đèn, Select và Activate, realtime lighting |
| 03 | [Near–Far and Ray Interactors](003-2-3-near-far-and-ray-interactors.md) | Direct/ray/near–far, XR Interaction Manager, troubleshooting |
| 04 | [User Interface](004-2-4-user-interface.md) | Canvas, Button, TextMeshPro, sự kiện và UI VR |
| 05 | [Challenge 2 — 3D Painting](005-challenge-2-3d-painting.md) | Nét vẽ 3D, điều khiển trạng thái, checkpoints |
| 06 | [XR Hardware Landscape](006-the-xr-hardware-landscape.md) | HMD, controller, tracking, hiệu năng và tương thích |
| 07 | [Lab 2 — Personal Project](007-lab-2-personal-project-events-interactions.md) | Mini-project, test cases, debug và sản phẩm cần nộp |
| 08 | [Mission 2 — Quiz](008-mission-2-quiz-vr-events-interactions.md) | 12 câu luyện tập cùng 3 tình huống thực hành |

## Cách sử dụng

1. Đọc theo thứ tự; thử từng kỹ năng bằng scene Unity nhỏ.
2. Giữ nguyên tên tiếng Anh của class, component, API trong Inspector để dễ tra cứu.
3. Với sơ đồ Mermaid, sử dụng trình đọc Markdown hỗ trợ Mermaid để hiển thị trực quan; nếu Google Drive chỉ hiển thị mã, có thể mở bằng VS Code Markdown Preview có hỗ trợ Mermaid.
4. Mỗi bài học có câu hỏi ôn tập; riêng bộ quiz cuối module là đề tự đánh giá, không có đáp án kèm theo.
5. Sau cùng, dùng [Lab 2](007-lab-2-personal-project-events-interactions.md) để tích hợp và tạo minh chứng thực hành.

## Nguồn tham khảo

- [Unity Learn — VR Development / Events and Interactions](https://learn.unity.com/pathway/vr-development/unit/events-and-interactions?version=6.3)
- Bộ tài liệu được tái cấu trúc từ các ghi chú Markdown đã cung cấp; một số ví dụ và bài kiểm tra được bổ sung nhằm phục vụ tự học, không tuyên bố là yêu cầu chính thức của Unity Learn.
