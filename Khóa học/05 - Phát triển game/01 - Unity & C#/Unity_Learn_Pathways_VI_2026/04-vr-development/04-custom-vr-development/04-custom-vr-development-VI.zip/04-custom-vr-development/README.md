# Custom VR Development — Tài liệu học tiếng Việt

Bộ bài dành cho Unity 6.3, tổ chức theo danh mục **VR Development → Mission 4: Custom VR Development**. Nội dung được **giảng lại và bổ sung bài tập, code minh họa**, không phải transcript hoặc lời giải chính thức của Unity Learn.

## Danh mục

| STT | Tài liệu | Nội dung chính |
|---:|---|---|
| 01 | [Khởi động mission](001-what-is-in-this-mission.md) | Tư duy input–logic–state–feedback |
| 02 | [Khám phá sample scene](002-explore-the-sample-scene.md) | Kiến trúc scene và truy vết event |
| 03 | [Thiết lập scanner](003-set-up-the-scanner.md) | Prefab, Muzzle, Collider, LayerMask |
| 04 | [Lập trình scanner](004-code-the-scanning-functionality.md) | Input System, Raycast, ScannableTarget |
| 05 | [Balloon Inflator](005-balloon-inflator.md) | Mức bơm, scale, UnityEvent |
| 06 | [Escape Room tổng quan](006-escape-room-project-overview.md) | Kiến trúc câu đố và điều kiện mở khóa |
| 07 | [Number Pad](007-number-pad.md) | Xử lý chuỗi nhập và xác thực |
| 08 | [Keycard Reader](008-keycard-reader.md) | Trigger Collider, thẻ hợp lệ |
| 09 | [Sliding Door](009-sliding-door.md) | MoveTowards, tốc độ, trạng thái |
| 10 | [Quiz tự luyện](010-mission-4-quiz-custom-vr-development.md) | 10 câu hỏi và giải thích |
| 11 | [Clone with a Twist](011-project-3-clone-with-a-twist.md) | Đồ án cuối và rubric |

## Kỹ thuật triển khai

- **Unity:** phiên bản tham chiếu 6.3; package XR Interaction Toolkit và Input System phải tương thích dự án.
- **XR/OpenXR:** cấu hình profile và build target theo headset thực tế.
- **Code:** ví dụ C# theo cơ chế Unity `MonoBehaviour`; cần tạo từng file `.cs` tương ứng khi áp dụng.
- **Kiểm thử:** ưu tiên thử cơ chế riêng trong Editor, sau đó kiểm tra hiệu năng và độ thoải mái trên HMD.

## Sơ đồ tiến trình

```mermaid
flowchart LR
  A[Khám phá scene] --> B[Scanner]
  B --> C[Balloon]
  C --> D[Number Pad + Keycard]
  D --> E[Sliding Door]
  E --> F[Quiz + Project]
```

**Nguồn đối chiếu:** [Unity Learn — Mission 4: Custom VR Development](https://learn.unity.com/pathway/vr-development/unit/mission-4-custom-vr-development?version=6.3). Các bài gốc/scene chính thức có thể cung cấp thao tác khác với ví dụ tự xây dựng ở đây.
